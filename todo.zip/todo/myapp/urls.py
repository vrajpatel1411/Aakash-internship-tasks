from django.urls import path
from . import views

urlpatterns = [
    path('',views.home,name="home"),
    path('registration',views.registration,name="registration"),
    path('register',views.register,name="register"),
    path('login',views.login,name="login"),
    path('add',views.add,name="add"),
    path('addtask',views.addtask,name="addtask"),
    path('view',views.view,name="view"),
    path('delete/<int:id>',views.delete,name="delete"),
]