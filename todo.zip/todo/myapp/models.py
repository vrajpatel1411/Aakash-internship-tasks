from django.db import models
from django.forms import ModelForm,Textarea



# Create your models here.

class registration_todo(models.Model):
    name=models.CharField(max_length=50)
    username=models.CharField(max_length=20)
    password=models.CharField(max_length=50)


