from django.shortcuts import render,redirect
from django.http import HttpResponse
import mysql.connector
import random,array

mydb=mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="vraj1411",
    database="django_first"
    )


mycursor=mydb.cursor()
# Create your views here.
def home(request):
    return render(request,"home.html")


def registration(request):
    msg=" "
    return render(request,"registration.html",{'msg':msg})

def register(request):
    if request.method=="POST":
        
        name=request.POST["name"]
        username=request.POST["username"]
        password=request.POST["password"]
        var=(name,username,password)
        try:
            sql="insert into  registartion_todo(name,username,password) values(%s,%s,%s)"
            mycursor.execute(sql,var)
            mydb.commit()
            msg="Your registration is sucessfull "
            return render(request,"login.html",{'msg':msg})
        except:
            msg="Add unique username or password"
            return render(request,"registration.html",{'msg':msg})
    else:
        return render(request,"login.html")


def login(request):

        un=request.POST["username"]
        password=request.POST["password"]
        try:
            
            sql="select password from  registartion_todo where username=%s"
            mycursor.execute(sql,(un,))
            myresult = mycursor.fetchone()
            request.session['username']=un
            request.session.set_expiry(388)
            print(myresult[0])
            if myresult[0]==password:
            
                return redirect(view)
            else:
                msg="Wrong password"
            return render(request,"login.html",{'msg':msg})
        except:
            msg="Wrong username or password"
            return render(request,"login.html",{'msg':msg})


def add(request):
    return render(request,"add.html")

def idgenerate():
    MAX_LEN = 10
    DIGITS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'] 
    COMBINED_LIST = DIGITS
    rand_digit = random.choice(DIGITS)
    temp_pass = rand_digit
    for x in range(MAX_LEN - 4):
        temp_pass = temp_pass + random.choice(COMBINED_LIST)
        temp_pass_list = array.array('u', temp_pass)
        random.shuffle(temp_pass_list)
    password = ""
    for x in temp_pass_list:
        password = password + x
    return password
    
def addtask(request):
    username=request.session["username"]
    sql="select user_id,name from registartion_todo where username=%s"
    mycursor.execute(sql,(username,))
    print(username)
    myresult=mycursor.fetchall()
    print(myresult)
    userid=myresult[0][0]
    name=myresult[0][1]
    title=request.POST["title"]
    details=request.POST["details"]
    date=request.POST["date"]
    taskid=idgenerate()
    sql="insert into task_todo2(user_id,name,username,task_name,Date_time,Date,task_value,title) values(%s,%s,%s,%s,CURRENT_TIMESTAMP(),%s,%s,%s)"
    var=(userid,name,username,details,date,taskid,title,)
    mycursor.execute(sql,var)
    mydb.commit()
    return redirect(view)

def view(request):
    username=request.session["username"]
    sql="select title,task_name,Date,task_value from task_todo2 where username=%s"
    mycursor.execute(sql,(username,))
    myresult=mycursor.fetchall()
    list1=list(myresult)
    return render(request,"first.html",{'list':list1,'msg':username})



def delete(request,id):
    username=request.session["username"]
    sql="delete from task_todo2 where task_value={}".format(id)
    print(id)
    mycursor.execute(sql)
    print(mycursor)
    mydb.commit()
    sql="select title,task_name,Date,task_value from task_todo2 where username=%s"
    mycursor.execute(sql,(username,))
    myresult=mycursor.fetchall()
    list1=list(myresult)
    print(list1)
    return redirect(view)