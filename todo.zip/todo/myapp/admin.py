from django.contrib import admin

# Register your models here.

from .models import registration_todo

admin.site.register(registration_todo)